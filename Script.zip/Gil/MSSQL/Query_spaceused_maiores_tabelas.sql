declare @stmt nvarchar(2000)

create table #space_used (
	name varchar(128),
	rows int,
	reserved varchar(30),
	data varchar(30),
	index_size varchar(30),
	unused varchar(30)
)

create table #space_used2 (
	name varchar(128),
	rows int,
	reserved_kb int,
	data_kb int,
	index_size_kb int,
	unused_kb int
)

exec sp_MSforeachtable 'insert into #space_used exec sp_spaceused [?]'
	
insert into #space_used2
	select	name,
			rows,
			convert(int, ltrim(rtrim(replace(reserved, 'KB', '')))),
			convert(int, ltrim(rtrim(replace(data, 'KB', '')))),
			convert(int, ltrim(rtrim(replace(index_size, 'KB', '')))),
			convert(int, ltrim(rtrim(replace(unused, 'KB', ''))))
	from #space_used

select * from #space_used2
order by reserved_kb desc

select top 1 name as maior_tabela, reserved_kb / 1024 as reserved_MB
from #space_used2
order by reserved_kb desc


set @stmt = 'exec master..sp_t4b_getspace ''' + db_name() + ''''
exec(@stmt)

drop table #space_used
drop table #space_used2