use t4bdb01
go

DECLARE @coll_master varchar(50),
	@cmd nvarchar(2000)
  
set nocount on  
  
CREATE TABLE #Collation (
	coll varchar(50)
)

IF NOT REPLACE(@@VERSION, '  ', ' ') LIKE 'Microsoft SQL Server 7%'
BEGIN
	insert into #Collation (coll)
	exec('SELECT CONVERT(varchar, DATABASEPROPERTYEX(''master'', ''Collation''))')
END

SELECT @coll_master = ISNULL(coll, '') FROM #Collation

set @cmd = 'select tpp.DBNAME as [Bancos sem backup de log] from t4b_procadm_param as tpp
	inner join master..sysdatabases as sd on tpp.DBNAME = sd.name'

IF NOT REPLACE(@@VERSION, '  ', ' ') LIKE 'Microsoft SQL Server 7%'
BEGIN
	set @cmd = replace(@cmd, 'tpp.DBNAME = sd.name', 'tpp.DBNAME COLLATE ' + @coll_master + ' = sd.name')
END

set @cmd = @cmd + char(13) + 'where DATABASEPROPERTY(tpp.DBNAME, ''IsTruncLog'') = 0
	and lower(tpp.DBNAME) != ''model''
	and tpp.BACKUP_LOG = 0'

select @@servername as SERVIDOR
exec(@cmd)

DROP TABLE #Collation
set nocount off

