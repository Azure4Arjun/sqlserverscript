use t4bdb01
go

set nocount on

/*******************************************************************************************************
	SCRIPT:		INSERT_novo_banco_rotinas_adm.sql
	AUTOR:		[Gil]
	FUN��O:		Inclui um novo banco nas rotinas adm da Tech4B
	PRE-REQ:	Ter, pelo menos, um banco j� incluso na t4b_procadm_param do banco t4bdb01.
*******************************************************************************************************/

declare @cols varchar(2000),
		@col varchar(50),
		@stmt nvarchar(2000),
		@vals varchar(2000),
		@val varchar(500),
		@colbanco varchar(10),
		@novobanco varchar(100)

set @novobanco = '###DIGITE AQUI O NOME DO NOVO BANCO###'	-- DIGITAR AQUI O NOME DO BANCO

if @novobanco = '###DIGITE AQUI O NOME DO NOVO BANCO###'	-- N�o alerar essa linha.
begin
	RAISERROR('N�o foi informado o nome do novo banco!!!', 16, 1)
end
else
begin
	create table #colsProcAdm (col varchar(50), val varchar(1000))

	select @cols = ''
	select @vals = ''

	select @colbanco = name
	from syscolumns
	where id = object_id('t4b_procadm_param') and name in ('BANCO', 'DBNAME')

	declare cur_col cursor for
		select name from syscolumns
		where id = object_id('t4b_procadm_param')

	open cur_col

	fetch next from cur_col
		into @col

	while @@fetch_status = 0
	begin
		-- monta a string das colunas:
		select @cols = @cols + char(13) + char(9) + @col + ','

		select @stmt = '
			SELECT TOP 1 ''' + @col + ''', ' + @col + '
			FROM t4b_procadm_param
			WHERE ' + @colbanco + ' NOT IN (''master'', ''model'', ''tempdb'', ''msdb'')'

		insert into #colsProcAdm
			exec(@stmt)

		select @val = ISNULL(val, '[NULL]') from #colsProcAdm where col = @col

		if @col in ('BANCO', 'DBNAME')
			select @val = @novobanco
		-- monta a string dos valores das colunas:
		if isnumeric(@val) = 1
			select @vals = @vals + char(13) + char(9) + @val + ','
		else
			select @vals = @vals + char(13) + char(9) + '''' + @val + ''','

		fetch next from cur_col
			into @col
	end

	close cur_col
	deallocate cur_col

	select @cols = substring(@cols, 1, len(@cols) - 1)
	select @vals = substring(@vals, 1, len(@vals) - 1)
	select @vals = replace(@vals, '''[NULL]''', 'NULL')

	select @stmt = 'INSERT INTO t4b_procadm_param (' + @cols + char(13) + ') VALUES (' + @vals + char(13) + ')'
	exec(@stmt)

	print 'O banco [' + @novobanco + '] foi inserido com sucesso na tabela das rotinas administrativas.'

	drop table #colsProcAdm
end
set nocount off