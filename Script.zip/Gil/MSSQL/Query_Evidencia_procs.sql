use PGS_MAIN
go

--setuser 'pgs'
SET NOCOUNT ON

select convert(char(50), @@SERVERNAME) as SERVIDOR

select convert(char(50), db_name()) AS BANCO

select convert(char(50), name) as name, type, crdate
from sysobjects
where type = 'p'
and crdate between '2011-01-10 00:00:00' and '2011-01-10 23:59:59'


SET NOCOUNT OFF