Select Distinct

SysObjects.Name 'Table Name', 

Procedures.Name 'Stored Procedure'

 

From SysObjects 

Join (SysObjects Procedures 

Join SysDepends 

on Procedures.Id = SysDepends.Id) 

On SysDepends.DepId = SysObjects.Id

 

Where SysObjects.XType = 'U'

 

-- Change XType Values here using chart above

And Procedures.XType = 'P'

 

Group by SysObjects.Name, 

SysObjects.Id, 

Procedures.Name

 

Order by SysObjects.Name Asc
