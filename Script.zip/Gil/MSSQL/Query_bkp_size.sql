sp_MSforeachdb
'select top 1 backup_size / 1073741824 as [? em GB]
from msdb..backupset
where database_name = ''?''
	and type = ''D''
order by backup_start_date desc'
