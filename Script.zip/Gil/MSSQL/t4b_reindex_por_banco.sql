--use []
GO

CREATE TABLE #showcontig_temp (
	OBJECTNAME [VARCHAR](128) NULL,
	OBJECTID [INT] NULL,
	INDEXNAME [VARCHAR](128) NULL,
	INDEXID [INT] NULL,
	[LEVEL] [INT] NULL,
	PAGES [INT] NULL,
	ROWS [INT] NULL,
	MINIMUMRECORDSIZE [INT] NULL,
	MAXIMUMRECORDSIZE [INT] NULL,
	AVERAGERECORDSIZE [FLOAT] NULL,
	FORWARDEDRECORDS [FLOAT] NULL,
	EXTENTS [INT] NULL,
	EXTENTSSWITCHES [INT] NULL,
	AVERAGEFREEBYTES [FLOAT] NULL,
	AVERAGEPAGEDENSITY [FLOAT] NULL,
	SCANDENSITY [FLOAT] NULL,
	BESTCOUNT [INT] NULL,
	ACTUALCOUNT [INT] NULL,
	LOGICALFRAGMENTATION [FLOAT] NULL,
	EXTENTFRAGMENTATION [FLOAT] NULL
)

CREATE TABLE #showcontig_temp_db (  
	DBNAME [VARCHAR](128) NULL,
	OBJECTNAME [VARCHAR](128) NULL,
	INDEXID [INT] NULL,
	ROWS [INT] NULL,
	SCANDENSITY [FLOAT] NULL
)

CREATE TABLE #t4b_reindex (  
	HOSTNAME [VARCHAR](128),
	DBNAME [VARCHAR](128),
	OBJECTNAME [VARCHAR](128),
	ROWS [INT]
)

CREATE TABLE #t4b_reindex_cursor (  
	OBJECTNAME [VARCHAR](128),
	ROWS [INT]
)

CREATE TABLE #t4b_spaceused (
	[NAME] [VARCHAR](128) NULL,
	[ROWS] [INT] NULL,
	[RESERVED] [VARCHAR](20) NULL,
	[DATA] [VARCHAR](20) NULL,
	[INDEX_SIZE] [VARCHAR](20) NULL,
	[UNUSED] [VARCHAR](20) NULL
)

-- GRAVA O TAMANHO DO LOGFILE NA t4b_procadm_param PARA RETORNAR O LOG AP�S O REINDEX.
CREATE TABLE #t4b_logspace (
	banco varchar(60),
	logS decimal(15,8),
	logU decimal(15,8),
	status int
)

INSERT INTO #t4b_logspace
	EXEC('DBCC SQLPERF(LOGSPACE)')

		UPDATE t4bdb01..t4b_procadm_param
			SET t4bdb01..t4b_procadm_param.THRESH_LG_SIZE = CEILING(#t4b_logspace.logS)
		FROM t4bdb01..t4b_procadm_param
		INNER JOIN #t4b_logspace ON t4bdb01..t4b_procadm_param.[DBNAME] = #t4b_logspace.banco

/*
SET @stmt = 'EXEC ' + @dbname + '..sp_t4b_adm_reindex'
EXEC(@stmt)
*/

--- Trecho copiado da procedure master..sp_t4b_adm_reindex ----------------------------------------
	-- Obtendo collation do tempdb, para n�o dar problema na compara��o entre os campos data tabela tempor�ria e os da t4b_procadm_param
	DECLARE @currdate [VARCHAR](20),
			@server [VARCHAR](60),
			@dbname [VARCHAR](128),
			@starttime [DATETIME],
			@endtime [DATETIME],
			@etime [INT],
			@cmd [VARCHAR](500),
			@objectname [VARCHAR](128),
			@rows [INT],
			@reserved [VARCHAR](20),
			@data [VARCHAR](20),
			@index_size [VARCHAR](20),
			@unused [VARCHAR](20),
			@stmt nvarchar(1000),
			@collation_tempdb varchar(50)

	CREATE TABLE #Collation (
		coll varchar(50)
	)

	SELECT  @server = @@SERVERNAME,
			@dbname = DB_NAME()

	IF NOT REPLACE(@@VERSION, '  ', ' ') LIKE 'Microsoft SQL Server 7%'
	BEGIN
		insert into #Collation (coll)
		exec('SELECT CONVERT(varchar, DATABASEPROPERTYEX(''tempdb'', ''Collation''))')
	END

	SELECT @collation_tempdb = ISNULL(coll, '') FROM #Collation

	DROP TABLE #Collation

	IF REPLACE(@@VERSION, '  ', ' ') LIKE 'Microsoft SQL Server 7%'
	BEGIN
		SELECT @stmt = 'sp_MSforeachtable ''DBCC DBREINDEX([?])'''
	END
	ELSE
	BEGIN
		SELECT @stmt = 'DBCC SHOWCONTIG WITH TABLERESULTS, ALL_INDEXES'
	END

	INSERT INTO #showcontig_temp  
	EXEC (@stmt)    

	INSERT INTO #showcontig_temp_db  
	SELECT @dbname 'DBNAME',  
		   OBJECTNAME,  
		   INDEXID,  
		   ROWS,  
		   SCANDENSITY  
	FROM #showcontig_temp

	-- Verificando tamb�m o nivel de compatibilidade do banco:
	IF (NOT REPLACE(@@VERSION, '  ', ' ') LIKE 'Microsoft SQL Server 7%') AND
		((SELECT cmptlevel from master..sysdatabases WHERE name = @dbname) != 70)
	BEGIN
		SELECT @stmt = '
			INSERT INTO #t4b_reindex  
			SELECT @@SERVERNAME,  
				   DB_NAME(),  
				   st.OBJECTNAME,  
				   st.ROWS  
			FROM    #showcontig_temp_db st, [t4bdb01].[dbo].[t4b_procadm_param] tpp  
			WHERE st.DBNAME = tpp.DBNAME COLLATE ' + @collation_tempdb + '
			AND   st.INDEXID > 0  
			AND   st.SCANDENSITY < tpp.THRESH_REINDEX  
			AND   OBJECT_ID(st.OBJECTNAME) > 100'
		
		EXEC(@stmt)
	END
	ELSE
	BEGIN
		SELECT @stmt = '
			INSERT INTO #t4b_reindex  
			SELECT @@SERVERNAME,  
				   DB_NAME(),  
				   st.OBJECTNAME,  
				   st.ROWS  
			FROM    #showcontig_temp_db st, [t4bdb01].[dbo].[t4b_procadm_param] tpp  
			WHERE st.DBNAME = tpp.DBNAME  
			AND   st.INDEXID > 0  
			AND   st.SCANDENSITY < tpp.THRESH_REINDEX  
			AND   OBJECT_ID(st.OBJECTNAME) > 100'
		
		EXEC(@stmt)
	END

	-- Verificando tamb�m o nivel de compatibilidade do banco:
	IF (NOT REPLACE(@@VERSION, '  ', ' ') LIKE 'Microsoft SQL Server 7%') AND
		((SELECT cmptlevel from master..sysdatabases WHERE name = @dbname) != 70)
	BEGIN
		
		SELECT @stmt = '
			DELETE FROM #t4b_reindex  
			FROM    #t4b_reindex r, [t4bdb01].[dbo].[t4b_reindex_param] rp  
			WHERE   r.HOSTNAME = rp.HOSTNAME COLLATE ' + @collation_tempdb + '
			AND  r.DBNAME = rp.DBNAME COLLATE ' + @collation_tempdb + '
			AND  r.OBJECTNAME = rp.OBJECTNAME  COLLATE ' + @collation_tempdb
		EXEC(@stmt)

	END
	ELSE
	BEGIN
		SELECT @stmt = '
			DELETE FROM #t4b_reindex  
			FROM    #t4b_reindex r, [t4bdb01].[dbo].[t4b_reindex_param] rp  
			WHERE   r.HOSTNAME = rp.HOSTNAME 
			AND  r.DBNAME = rp.DBNAME  
			AND  r.OBJECTNAME = rp.OBJECTNAME'
		EXEC(@stmt)
	END

	-- Exclui-se da #t4b_reindex o que n�o for user table:
	CREATE TABLE #soAux (
		name varchar(128),
		type char(3)
	)

	INSERT INTO #soAux
		SELECT name, type FROM sysobjects

	DELETE #t4b_reindex
	FROM #t4b_reindex
		INNER JOIN #soAux on #t4b_reindex.OBJECTNAME = #soAux.name
	WHERE #soAux.type != 'U'

	DROP TABLE #soAux

	INSERT INTO #t4b_reindex_cursor  
	SELECT OBJECTNAME,  
	  MAX(ROWS)  
	FROM    #t4b_reindex  
	GROUP BY OBJECTNAME  

	DECLARE cur_tb CURSOR FOR    
	SELECT  QUOTENAME(OBJECTNAME)  
	FROM    #t4b_reindex_cursor  
	ORDER BY ROWS  
	  
	OPEN cur_tb    
	    
	FETCH   cur_tb    
	INTO    @objectname  
	    
	WHILE @@FETCH_STATUS = 0    
	BEGIN    

		SELECT @cmd = 'DBCC DBREINDEX (''' + USER_NAME(OBJECTPROPERTY(OBJECT_ID(@objectname),'OwnerId')) + '.' + @objectname + ''') WITH NO_INFOMSGS'  
	  
		INSERT INTO #t4b_spaceused  
		EXEC sp_spaceused @objectname  
	  
		SELECT @starttime = GETDATE()  
	  
		SELECT @rows = ROWS,  
		 @reserved = RESERVED,  
		 @data = DATA,  
		 @index_size = INDEX_SIZE,  
		 @unused = UNUSED  
		FROM #t4b_spaceused  
	  
		INSERT INTO [t4bdb01].[dbo].[t4b_info_reindex]  
		VALUES (@starttime,NULL,@@SERVERNAME,DB_NAME(),@objectname,NULL,@rows,@reserved,@data,@index_size,@unused)  
	  
		EXEC (@cmd)  
	  
		SELECT @endtime = GETDATE()  
	  
		INSERT INTO #t4b_spaceused  
		EXEC sp_spaceused @objectname  
	  
		SELECT @rows = ROWS,  
		 @reserved = RESERVED,  
		 @data = DATA,  
		 @index_size = INDEX_SIZE,  
		 @unused = UNUSED  
		FROM #t4b_spaceused  
	  
		SELECT @etime = DATEDIFF(ss,@starttime,@endtime)  
	  
		TRUNCATE TABLE #t4b_spaceused  
	  
		INSERT INTO [t4bdb01].[dbo].[t4b_info_reindex]  
		VALUES (@starttime,@endtime,@@SERVERNAME,DB_NAME(),@objectname,@etime,@rows,@reserved,@data,@index_size,@unused)  
	    
		   FETCH   cur_tb    
		   INTO    @objectname   
	END    
	    
	CLOSE cur_tb
	DEALLOCATE cur_tb

-- /Trecho copiado da procedure master..sp_t4b_adm_reindex ----------------------------------------


DROP TABLE #t4b_logspace
DROP TABLE #showcontig_temp 
DROP TABLE #showcontig_temp_db 
DROP TABLE #t4b_reindex 
DROP TABLE #t4b_reindex_cursor 
DROP TABLE #t4b_spaceused 
