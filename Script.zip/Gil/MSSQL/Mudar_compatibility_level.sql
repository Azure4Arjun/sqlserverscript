USE [master]
GO
EXEC dbo.sp_dbcmptlevel @dbname=N't4bdb01', @new_cmptlevel=80
GO
