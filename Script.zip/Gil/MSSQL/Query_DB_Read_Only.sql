if (select status & 1024 from master..sysdatabases where name = @dbname) != 0
begin
	-- c�digo para banco read only.
end