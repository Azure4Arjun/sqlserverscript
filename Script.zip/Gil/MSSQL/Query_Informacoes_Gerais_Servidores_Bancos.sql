use t4bdb01
GO

declare @stmt nvarchar(4000)

CREATE TABLE ##TAB_BD(
	[SERVIDOR] varchar(100),
	[INSTANCIA] varchar(100),
	[BANCO] varchar(100),
	[DATA_CRIACAO] datetime,
	[CRIADOR] varchar(100),
	[TECNOLOGIA] varchar(25),
	[VERSAO] varchar(100),
	[RECOVERY] varchar(20),
	[COLLATION] varchar(50),
	[READ_ONLY] char(3),
	[ROTINAS_ADM] char(3),
	[FREQ_BACKUP] varchar(20),
	[NRO_VERSAO] varchar(50)
)

insert into ##TAB_BD
	select 
		CASE 
			WHEN CONVERT(varchar, @@SERVERNAME) LIKE '%\%' THEN REPLACE(SUBSTRING(@@SERVERNAME,1,CHARINDEX('\',@@SERVERNAME)), '\', '')
			ELSE CONVERT(varchar, @@SERVERNAME)
		END as [SERVIDOR],
		CASE 
			WHEN CONVERT(varchar, @@SERVERNAME) LIKE '%\%' THEN REPLACE(SUBSTRING(@@SERVERNAME,CHARINDEX('\',@@SERVERNAME),LEN(@@SERVERNAME)-CHARINDEX('\',@@SERVERNAME)+1), '\', '')
			ELSE CONVERT(varchar, @@SERVERNAME)
		END as [INSTANCIA],
		sd.name as [BANCO],
		sd.crdate as [DATA_CRIACAO],
		sl.name as [CRIADOR],
		'MS SQL' AS [TECNOLOGIA],
		CASE
			WHEN CONVERT(varchar, SERVERPROPERTY('productversion')) LIKE '8.0%' THEN '2000'
			WHEN CONVERT(varchar, SERVERPROPERTY('productversion')) LIKE '9.0%' THEN '2005'
			WHEN CONVERT(varchar, SERVERPROPERTY('productversion')) LIKE '10.0%' THEN '2008'		
		END+ ' ' + CONVERT(varchar, SERVERPROPERTY ('edition')) + ' ' + CONVERT(varchar, SERVERPROPERTY ('productlevel')) as [VERSAO],
		CONVERT(varchar, DATABASEPROPERTYEX(sd.name, 'Recovery')) as [RECOVERY],
		CONVERT(varchar, DATABASEPROPERTYEX(sd.name, 'Collation')) as [COLLATION],
		CASE
			WHEN (sd.status & 1024) != 0 THEN 'SIM'
			ELSE 'NAO'
		END as [READ_ONLY],
		NULL as [ROTINAS_ADM],
		NULL as [FREQ_BACKUP],
		CONVERT(varchar, SERVERPROPERTY('productversion')) as [NRO_VERSAO]
	from master..sysdatabases sd
		left join master..syslogins sl on sd.sid = sl.sid


if exists (select 1 from syscolumns where id = OBJECT_ID('t4b_procadm_param') and name = 'DBNAME')
BEGIN
	set @stmt = '
	if exists (select 1 from t4b_procadm_param where DBNAME = ''?'')
	BEGIN
		update ##TAB_BD
			set [ROTINAS_ADM] = ''SIM''
		where [BANCO] = ''?''

		update ##TAB_BD
			set [FREQ_BACKUP] = (select case BACKUP_FULL
											when 1 THEN ''DIARIO''
											else ''VERIFICAR''
										end
								 from t4b_procadm_param
								 where DBNAME = ''?'')
		where [BANCO] = ''?''
	END
	else
	BEGIN
		update ##TAB_BD
			set [ROTINAS_ADM] = ''NAO'',
				[FREQ_BACKUP] = ''VERIFICAR''
		where [BANCO] = ''?''
	END'
END
ELSE
BEGIN
	set @stmt = '
	if exists (select 1 from t4b_procadm_param where BANCO = ''?'')
	BEGIN
		update ##TAB_BD
			set [ROTINAS_ADM] = ''SIM''
		where [BANCO] = ''?''

		update ##TAB_BD
			set [FREQ_BACKUP] = (select case BACKUP_FULL
											when 1 THEN ''DIARIO''
											else ''VERIFICAR''
										end
								 from t4b_procadm_param
								 where BANCO = ''?'')
		where [BANCO] = ''?''
	END
	else
	BEGIN
		update ##TAB_BD
			set [ROTINAS_ADM] = ''NAO'',
				[FREQ_BACKUP] = ''VERIFICAR''
		where [BANCO] = ''?''
	END'	
END

exec sp_MSforeachdb @stmt

SELECT * FROM ##TAB_BD

DROP TABLE ##TAB_BD