CREATE TABLE #t4b_info_diskspace(
	[TIMESTAMP] [datetime] NULL,
	[SERVER] [varchar](100) NULL,
	[DRIVELETTER] [char](1) NULL,
	[LABEL] [varchar](50) NULL,
	[FREESPACE_MB] [int] NULL,
	[USEDSPACE_MB] [int] NULL,
	[TOTALSPACE_MB] [int] NULL,
	[PERCENTAGE_USED] [decimal](5, 2) NULL
) 

CREATE TABLE #spaces_disk (
	time_stamp	DATETIME,
	drive CHAR(1),
	totalBytes	DECIMAL(16,0),
	freeBytes	DECIMAL(16,0))

DECLARE @time_stamp DATETIME,
		@fs	INT,
		@drive INT,
		@hr INT,
		@src VARCHAR(255),
		@desc VARCHAR(255),
		@driveLetter VARCHAR(255),
		@totalBytes	DECIMAL(16,0),
		@freeBytes	DECIMAL(16,0),
		@usedBytes	DECIMAL(16,0),
		@pctUsed	DECIMAL(5,2),
		@volume		varchar(60)

SELECT	@time_stamp = GETDATE()

EXEC @hr = sp_OACreate 'Scripting.FileSystemObject', @fs OUT;
IF @hr <> 0
BEGIN
   EXEC sp_OAGetErrorInfo @fs, @src OUT, @desc OUT 
   RAISERROR('Error Creating COM Component 0x%x, %s, %s',16,1, @hr, @src, @desc)
	RETURN
END

DECLARE cur_drive CURSOR FOR
SELECT	DISTINCT SUBSTRING(filename, 1,1)
FROM	master..sysaltfiles
WHERE	size > 0
ORDER BY 1
FOR READ ONLY

OPEN cur_drive

FETCH cur_drive INTO @driveLetter

WHILE @@FETCH_STATUS = 0
BEGIN
	EXEC @hr = sp_OAMethod @fs, 'GetDrive', @drive OUT, @driveLetter
	IF @hr <> 0
	BEGIN
		PRINT 'GetDrive'
		EXEC sp_OAGetErrorInfo @fs

	END

	DECLARE @property varchar(255)
	EXEC @hr = sp_OAMethod @drive, 'TotalSize', @property OUT
	IF @hr <> 0
	BEGIN
		PRINT 'Total'
		EXEC sp_OAGetErrorInfo @fs

	END
	
	SET @totalBytes = CONVERT(DECIMAL(16,0),@property)

	EXEC @hr = sp_OAMethod @drive, 'FreeSpace', @property OUT
	IF @hr <> 0
	BEGIN
		PRINT 'Free'
		EXEC sp_OAGetErrorInfo @fs

	END
	
	SET @freeBytes = CONVERT(DECIMAL(16,0),@property)

	------------------------------------------------------------
	EXEC @hr = sp_OAMethod @drive, 'VolumeName', @property OUT
	IF @hr <> 0
	BEGIN
		PRINT 'VolumeName'
		EXEC sp_OAGetErrorInfo @fs

	END
	
	SET @volume = CONVERT(VARCHAR,@property)
	------------------------------------------------------------

	EXEC sp_OADestroy @drive
/*
	INSERT INTO t4b_disk_space (time_stamp, disk, total, free)
	SELECT @time_stamp, @driveLetter, @totalBytes, @freeBytes
*/

	SET @freeBytes = @freeBytes / (1024 * 1024)
	SET @totalBytes = @totalBytes / (1024 * 1024)
	SET @usedBytes = @totalBytes - @freeBytes
	SET @pctUsed = 100 - ( CONVERT([NUMERIC](5,2),((CONVERT([NUMERIC](9,0),@freeBytes) / CONVERT([NUMERIC](9,0),@totalBytes)) * 100)) )

	--100 - ( CONVERT([NUMERIC](5,2),((CONVERT([NUMERIC](9,0),[FREESPACE]) / CONVERT([NUMERIC](9,0),[TOTALSPACE])) * 100)) )

PRINT @driveLetter
PRINT @freeBytes
PRINT @volume
PRINT @pctUsed
PRINT @@servername
PRINT @time_stamp
PRINT @totalBytes
PRINT @usedBytes



	INSERT INTO #t4b_info_diskspace(
		DRIVELETTER,
		FREESPACE_MB,
		LABEL,
		PERCENTAGE_USED,
		[SERVER],
		[TIMESTAMP],
		TOTALSPACE_MB,
		USEDSPACE_MB
	) VALUES (
		@driveLetter,
		@freeBytes,
		@volume,
		@pctUsed,
		@@servername,
		@time_stamp,
		@totalBytes,
		@usedBytes
	)
	FETCH cur_drive INTO @driveLetter
END

CLOSE cur_drive
DEALLOCATE cur_drive

DROP TABLE #spaces_disk

EXEC sp_OADestroy @drive
EXEC sp_OADestroy @fs	

SELECT * FROM #t4b_info_diskspace

SELECT
	SUM(FREESPACE_MB) AS FREESPACE_ALLDRIVES_MB,
	SUM(USEDSPACE_MB) AS USEDSPACE_ALLDRIVES_MB,
	SUM(TOTALSPACE_MB) AS TOTALSPACE_ALLDRIVES_MB
FROM #t4b_info_diskspace

DROP TABLE #t4b_info_diskspace
