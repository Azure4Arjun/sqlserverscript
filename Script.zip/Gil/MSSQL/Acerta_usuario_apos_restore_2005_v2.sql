set nocount on
select 'sp_change_users_login "update_one", "'+ name +'", "'+ name + '"' + char(10) + 'go' + char(10)
from sysusers
where name not in (
	'db_accessadmin',
	'db_backupoperator',
	'db_datareader',
	'db_datawriter',
	'db_ddladmin',
	'db_denydatareader',
	'db_denydatawriter',
	'db_owner',
	'db_securityadmin',
	'dbo',
	'guest',
	'INFORMATION_SCHEMA',
	'public',
	'sys',
	'MSmerge_PAL_role',
	'replmonitor'
)
set nocount off