select @@servername AS [SERVIDOR], GETDATE() AS [HORA]

select
	sd.name AS [BANCO],
	sd.crdate AS [DATA_DE_CRIACAO],
	l.name [CRIADOR]
from master..sysdatabases sd
	inner join master..syslogins l on sd.sid = l.sid
where sd.crdate > '2010-03-24'
order by sd.name

