/*
CREATE DATABASE [t4bdb02]
ON (NAME = N't4bdb02_Data', FILENAME = N'E:\MSSQL\Data\t4bdb02_Data.mdf' , SIZE = 6000, MAXSIZE = 7000, FILEGROWTH = 10%)
LOG ON (NAME = N't4bdb02_Log', FILENAME = N'G:\MSSQL\Data\t4bdb02_Log.ldf' , SIZE = 1000, MAXSIZE = 1001, FILEGROWTH = 10%)
*/


restore database t4bdb02
from disk=N'W:\BKPSQLCOMP\ACSWQT01\Bkp_novas_rotinas\t4bdb01_0.bkp',
	disk=N'W:\BKPSQLCOMP\ACSWQT01\Bkp_novas_rotinas\t4bdb01_1.bkp',
	disk=N'W:\BKPSQLCOMP\ACSWQT01\Bkp_novas_rotinas\t4bdb01_2.bkp',
	disk=N'W:\BKPSQLCOMP\ACSWQT01\Bkp_novas_rotinas\t4bdb01_3.bkp'
with replace,
move 't4bdb01_Data' to 'E:\MSSQL\Data\t4bdb02_Data.mdf',
move 't4bdb01_Log' to 'G:\MSSQL\Data\t4bdb02_Log.ldf'
