use t4bdb01
GO

declare @dtIni datetime,
		@dtFin datetime
		
set @dtIni = '2010-12-06 00:00:00'
set @dtFin = '2010-12-06 23:59:59'

select * from t4b_info_frag
where STARTTIME between @dtIni and @dtFin
and DBNAME = 'opvd'
order by TBNAME, IXNAME, STARTTIME, ENDTIME