use msdb
GO

exec sp_cycle_errorlog
GO

RAISERROR('Teste - Errorlog', 16, 1) WITH LOG
GO

execute sp_start_job @job_name = 'T4B_ERRORLOG'
GO
