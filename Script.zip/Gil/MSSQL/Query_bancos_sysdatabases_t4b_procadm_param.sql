-- Bancos a mais na t4b_procadm_param:
select tpp.DBNAME
from t4bdb01..t4b_procadm_param tpp
	left join master..sysdatabases sdb on tpp.DBNAME = sdb.name
where sdb.name is null
order by tpp.DBNAME


-- Bancos ausentes na t4b_procadm_param:
select sdb.name
from master..sysdatabases sdb
	left join t4bdb01..t4b_procadm_param tpp on tpp.DBNAME = sdb.name
where tpp.DBNAME is null
order by sdb.name



select count(*) AS Count_sysdatabases from master..sysdatabases
select count(*) AS Count_t4b_procadm_param from t4bdb01..t4b_procadm_param 