create table #DBFILES (
	banco varchar(128),
	tamanho_MB int,
	path_Data varchar(256),
	path_Log varchar(256)
)

insert into #DBFILES
	select
		sd.name,
		(select (sum(size) * 8) / 1024 from sysaltfiles where dbid = sd.dbid and fileid != 2),
		(select top 1 filename from sysaltfiles where dbid = sd.dbid and fileid = 1),
		(select top 1 filename from sysaltfiles where dbid = sd.dbid and fileid = 2)
	from sysdatabases sd

select * from #DBFILES

drop table #DBFILES
