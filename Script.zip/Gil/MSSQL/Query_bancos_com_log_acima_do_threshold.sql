declare @threshold int,
	@db varchar(128)

select @db = ''

if @db != ''
begin
	select @threshold = THRESH_LG_SPACE
	from t4bdb01..t4b_procadm_param
	WHERE DBNAME = @db
end
else
begin
	select @threshold = THRESH_LG_SPACE
	from t4bdb01..t4b_procadm_param
end

create table #LogSpace (
	db varchar(128),
	lgSize_MB float,
	lgUsed_Perc numeric(4, 2),
	status int
)

insert into #LogSpace
	exec ('dbcc sqlperf(logspace)')


select * from #LogSpace
where lgUsed_Perc > @threshold
order by lgUsed_Perc desc

drop table #LogSpace