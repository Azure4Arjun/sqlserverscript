Use msdb
go

SELECT --DISTINCT
	j.Name AS "Job Name",
	j.description AS "Job Description",
	SUBSTRING(CONVERT(varchar, h.run_date), 7, 2) + '/' + 
	SUBSTRING(CONVERT(varchar, h.run_date), 5, 2) + '/' + 
	SUBSTRING(CONVERT(varchar, h.run_date), 1, 4) + ' ' + 
	SUBSTRING(CONVERT(varchar, h.run_time), 1, 2) + ':' +
	SUBSTRING(CONVERT(varchar, h.run_time), 3, 2) + ':' +
	SUBSTRING(CONVERT(varchar, h.run_time), 5, 2)  AS LastStatusDate, 
	CASE h.run_status 
		WHEN 0 THEN 'Failed' 
		WHEN 1 THEN 'Successful' 
		WHEN 3 THEN 'Cancelled' 
		WHEN 4 THEN 'In Progress' 
	END AS [Status]
FROM sysjobhistory h
	INNER JOIN sysjobs j ON j.job_id = h.job_id
WHERE h.run_date = (SELECT MAX(hi.run_date)
					FROM sysjobhistory hi
					WHERE h.job_id = hi.job_id)
	AND h.step_id = 0
ORDER BY 1


/*
select * from sysjobhistory
where step_id = 0
*/

select count(*) from sysjobhistory

select instance_id from sysjobhistory order by 1