select @@SERVERNAME
go
select GETDATE()
go
sp_helpdb