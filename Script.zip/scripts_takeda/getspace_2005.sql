Text
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[sp_t4b_getspace]  
AS  
CREATE TABLE #showfilestats_final (  
 Banco VARCHAR(60),  
 Total DECIMAL(15,2),  
 Utilizado DECIMAL(15,2),  
 Livre DECIMAL(15,2)  
)  
CREATE TABLE #showlogstats (  
 Banco VARCHAR(60),  
 TotalLog DECIMAL(15,2),  
 Utilizado DECIMAL(15,2),  
 Status INT  
)  

create table #showstats(
SERVIDOR varchar(20),
INSTANCIA varchar(20),
BANCO varchar(300),
TAMANHO_BANCO_MB decimal(20,2),
LIVRE_BANCO_MB decimal(20,2),
PERC_OCUP decimal(20,2),
TAMANHO_LOG_MB decimal(20,2),
LOG_SPACE_USED decimal(20,2),
DATA varchar(20)
)
  
EXEC sp_MSForEachDb @command1 = '  
USE [?]
SET NOCOUNT ON  
  
CREATE TABLE #showfilestats (  
 Fileid INT,  
 FileGroup INT,  
 TotalExtents DECIMAL(15),  
 UsedExtents DECIMAL(15),  
 Name VARCHAR(255),  
 FileName VARCHAR(255))  
  
INSERT INTO #showfilestats  
EXEC (''DBCC SHOWFILESTATS WITH NO_INFOMSGS'')  
  
INSERT INTO #showfilestats_final  
SELECT db_name(),  
 Total = TotalExtents*65536/1024/1024,  
 Utilizado = UsedExtents*65536/1024/1024,  
 Livre = TotalExtents*65536/1024/1024 - UsedExtents*65536/1024/1024  
FROM #showfilestats  
  
DROP TABLE #showfilestats'  
  
INSERT INTO #showlogstats  
EXEC ('DBCC SQLPERF(LOGSPACE)')  
  
INSERT INTO #showstats SELECT SERVIDOR = CONVERT(VARCHAR,@@SERVERNAME),  
 INSTANCIA = CONVERT(VARCHAR,ISNULL(SERVERPROPERTY('InstanceName'), @@SERVERNAME)),  
 BANCO = CONVERT(VARCHAR,A.BANCO),  
 TAMANHO_BANCO_MB = A.Total,  
 LIVRE_BANCO_MB = A.Livre,  
 PERC_OCUP = 100 - CONVERT(DECIMAL(4,2),A.Livre * 100 / Total),  
 TAMANHO_LOG_MB = B.TotalLog,  
 LOG_SPACE_USED = B.Utilizado,  
 DATA = GETDATE()  
FROM #showfilestats_final A, #showlogstats B  
WHERE A.BANCO != 'model'  
AND A.BANCO = B.BANCO  
ORDER BY 1,2,3  


SELECT SERVIDOR ,
	INSTANCIA ,
	BANCO ,
	TAMANHO_BANCO_MB = sum(TAMANHO_BANCO_MB) ,
	LIVRE_BANCO_MB = sum(LIVRE_BANCO_MB) ,
	PERC_OCUP =  sum(PERC_OCUP) ,
	TAMANHO_LOG_MB =  sum(TAMANHO_LOG_MB) ,
	LOG_SPACE_USED = sum(LOG_SPACE_USED) ,
	DATA 
FROM #showstats
GROUP BY SERVIDOR , INSTANCIA , BANCO , DATA
ORDER BY 1,2,3    


DROP TABLE #showfilestats_final  
DROP TABLE #showlogstats  
DROP TABLE #showstats




