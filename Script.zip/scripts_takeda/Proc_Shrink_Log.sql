/*
====================================================================================================================================================
Cria��o de procedure que faz shrink da log de cada banco de dados automaticamente
====================================================================================================================================================
*/


IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id(N'[sp_t4b_shrink_log]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [sp_t4b_shrink_log]
GO

USE master
GO

CREATE PROCEDURE sp_t4b_shrink_log
AS

DECLARE @Command1 varchar (2000)
DECLARE @DB varchar(50)
DECLARE @LogFile varchar(100)

DECLARE cur_dados CURSOR
FOR	SELECT LTRIM(b.name) 'DB Name', LTRIM(a.name) 'Log File'
	FROM sysaltfiles a INNER JOIN sysdatabases b ON (a.dbid = b.dbid)
	WHERE groupid = 0

OPEN cur_dados

FETCH NEXT FROM cur_dados
INTO @DB, @LogFile

WHILE @@FETCH_STATUS = 0
BEGIN
	SELECT @Command1 = 'USE [' + @DB + ']
		DBCC SHRINKFILE (' + @LogFile + ', 1)'
	PRINT 'Executando SHRINK do Banco de Dados "' + @DB + '"'
	EXEC (@Command1)
	FETCH NEXT FROM cur_dados INTO @DB, @LogFile
END

CLOSE cur_dados
DEALLOCATE cur_dados
GO

----------------------------------

DROP PROCEDURE sp_t4b_shrink_log

sp_helptext sp_t4b_shrink_log

EXEC sp_t4b_shrink_log
