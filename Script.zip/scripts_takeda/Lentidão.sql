sp_who2 active

dbcc inputbuffer (436)

select * from ::fn_get_sql (sql_handle)

select * from sysprocesses where spid = 436