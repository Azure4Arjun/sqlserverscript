/*

            Verifica o tamanho dos bancos de dados do servidor.

            

            Criado por:        Marcelo Takeda

            Ves�o:              SLQ 7.0

            Data:                15/05/2007

*/

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 

set nocount on

 

declare @nomebd                      varchar(50)

declare @comando        varchar(1000)

--#########################################################################--

--Colocar parametros de procura

select   @nomebd                     =          null                   -- null = tudo

 

--#########################################################################--

 

--          Tabelas tempor�rias

 

--          Contagem de espa�o

create table ##space

(

            dbsize               dec(15,0)

,           logsize              dec(15,0)

,           bytesperpage     dec(15,0)

,           pagesperMB      dec(15,0)

,           maxsizeMB       dec(15,0)

)

 

--          Dados para serem enviados

create table ##dados

(

            nome_server      varchar(50)

,           nome_banco      varchar(50) not null

,           maximo             varchar(50)

,           database_size   varchar(10)

,           unallocated        varchar(10)

,           ocupado                        dec(15,2)

,           log_size            varchar(10)

,           tamanho_total    varchar(10)

)

 

--          Principal

select   name

into       #tmp_banco

from      master.dbo.sysdatabases sysdb

where    (name   <>        'master'

and       name    <>        'tempdb'

and       name    <>        'model'

and       name    <>        'msdb'

and       name    <>        'pubs'

and       name    <>        'Northwind')

and       name    =          isnull(@nomebd,sysdb.name)

 

while (select count(*) from #tmp_banco) <> 0

begin

            select top 1 @nomebd = name

                        from      #tmp_banco

 

/*Create temp tables before any DML to ensure dynamic

**  We need to create a temp table to do the calculation.

**  reserved: sum(reserved) where indid in (0, 1, 255)

**  data: sum(dpages) where indid < 2 + sum(used) where indid = 255 (text)

**  indexp: sum(used) where indid in (0, 1, 255) - data

**  unused: sum(reserved) - sum(used) where indid in (0, 1, 255)

*/

 

--          Carrega tabela de parametros ##space

            select @comando = 'use [' + @nomebd + '] 

            insert into ##space (dbsize, maxsizeMB)

            select sum(convert(dec(15),size)), ((sum(maxsize)*8))/1024 maxsizeMB

                        from dbo.sysfiles

                        where (status & 64 = 0)

                        and groupid > 0'

 

            exec (@comando)

 

            select @comando = 'use [' + @nomebd + '] 

            update ##space

            set bytesperpage = low

                        from master.dbo.spt_values

                        where number = 1

                                    and type = "E"'

 

            exec (@comando)

 

            select @comando = 'use [' + @nomebd + '] 

            update ##space

            set pagesperMB = 1048576 / bytesperpage

            from ##space'

 

            exec (@comando)

 

            select @comando = 'use [' + @nomebd + '] 

            insert into ##space

            select   sc.dbsize

            ,           logsize = sum(convert(dec(15),size))

            ,           sc.bytesperpage

            ,           sc.pagesperMB

            ,           sc.maxsizeMB

                        from dbo.sysfiles, ##space sc

                        where (status & 64 <> 0)

                        group by sc.dbsize, sc.bytesperpage, sc.pagesperMB, sc.maxsizeMB'

 

            exec (@comando)

            

 

            delete from ##space where logsize is null

 

 

 

            select @comando = 'use [' + @nomebd + '] 

insert into ##dados

select  @@servername,

db_name(),

maxsizeMB,

ltrim(str((dbsize) / pagesperMB,15,2)),

ltrim(str((dbsize - (select sum(convert(dec(15),reserved)) from sysindexes where indid in (0, 1, 255))) / pagesperMB,15,2)),

(((dbsize) / pagesperMB)) - (dbsize - (select sum(convert(dec(15),reserved)) from sysindexes where indid in (0, 1, 255))) / pagesperMB,

ltrim(str((logsize) / pagesperMB,15,2)),

ltrim(str((dbsize + logsize) / pagesperMB,15,2))

from ##space'

            from #tmp_banco

 

 

            exec (@comando)

 

            delete from #tmp_banco where @nomebd = name

            delete from ##space

 

end

 

select * from ##dados

 

drop table #tmp_banco

drop table ##space

drop table ##dados

 

set nocount off

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 

 

 

 

 

 

Att,

 


 
 Marcelo Takeda
DBA SQL Server
Rua do Arouche, 23 - 10� andar - 
Rep�blica | S�o Paulo | SP | Brasil | CEP.: 01219-001
Tel.: 55 11 3366 4255 | Fax.: 55 11 3366 4252
www.virtus-ti.com.br
 

 

 

 

 

 
