/*
======================================================================================================================================================
Verfica Liguagem do banco de dados e Default database de cada usu�rio
======================================================================================================================================================
*/

use master
go
--select * from syslogins

select name, language, dbname from syslogins order by language
go

select 'sp_defaultlanguage "' + name + '", "' + language + '"' + char(13) + 'go' + char(13)
from syslogins
where language <> 'us_english'
order by language
go

select 'sp_defaultdb "' + name + '", "' + dbname + '"' + char(13) + 'go' + char(13)
from syslogins
order by language
go



