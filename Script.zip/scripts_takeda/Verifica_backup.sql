declare @data_ref datetime

set @data_ref = null

set nocount on  
  
if @data_ref is null  
 select  @data_ref = convert(char(8), getdate(), 112)  
  

create table #tabaux
(server_name varchar(128) null,   
database_name varchar(128) null,  
type char(1) null,  
backup_start_date datetime null,  
backup_finish_date datetime null)  
  
insert #tabaux  
select  @@servername, db.name, 'D', isnull(max(backup_start_date), '19000101'), isnull(max(backup_finish_date), '19000101')  
from  msdb..backupset bkp,  
 master..sysdatabases db  
where  bkp.server_name = @@servername and  
 bkp.type = 'D' and  
 bkp.database_name =* db.name and  
 db.name not in ('tempdb','pubs','Northwind')  
group by db.name  

insert #tabaux  
select  @@servername, db.name, 'L', max(backup_start_date), max(backup_finish_date)  
from  msdb..backupset bkp, master..sysdatabases db  
where  bkp.server_name = @@servername and  
 bkp.type = 'L' and  
 db.name not in ('tempdb','pubs','Northwind') and  
 bkp.database_name =* db.name and  
 db.status = db.status & 16  
group by db.name  
  
delete #tabaux  
where type = 'D' and   
 backup_start_date between @data_ref and dateadd(dd, -1, @data_ref) and  
 backup_finish_date between @data_ref and dateadd(dd, -1, @data_ref)  
  
select  @data_ref = dateadd(hh, -1, getdate())  
  
delete #tabaux  
where type = 'L' and   
 backup_start_date >= @data_ref and  
 backup_finish_date >= @data_ref  
  
select 	convert(varchar(10),server_name) "server",
	convert(varchar(20),database_name) "database",
	convert(varchar(1),type) "type",
	convert(varchar(19),backup_start_date,120) "backup_start_date",
	convert(varchar(19),backup_finish_date,120) "backup_finish_date"
from #tabaux  



drop table #tabaux

