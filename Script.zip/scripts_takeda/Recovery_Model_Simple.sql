/*
=======================================================================================================================================================
Coloca todos os bancos de dados do servidor em Recovery Model Simple
=======================================================================================================================================================
*/

declare @dbname varchar(100), @tmp varchar(1000)
set nocount on 

declare cur_dbname cursor for
select name from master..sysdatabases where name not in ('master','model','msdb','tempdb','dba') order by name

open cur_dbname
fetch next from cur_dbname into @dbname 

select '*********** IN�CIO - recovery simple - '+convert(varchar(19),getdate(),121)+' ***********'
set nocount on 
while @@fetch_status = 0
begin
print '>> Alterando o Database: '+@dbname
select @tmp = 'alter database '+@dbname+' set recovery simple'
EXEC (@tmp)
fetch next from cur_dbname into @dbname
end
close cur_dbname
deallocate cur_dbname

select '*********** FIM - recovery simple - '+convert(varchar(19),getdate(),121)+' ***********'
go