select * from tttiex300000 --(verificar conteudo da tabela tttiex300000)

select * into bck_tttiex300000 from tttiex300000 --(fazer backup da  tabela tttiex300000)
select count(*) from bck_tttiex300000

select * from tttiex301000 --(verificar conteudo da tabela tttiex301000)

select * into bck_tttiex301000 from tttiex301000 --(fazer backup da  tabela tttiex301000)
select count(*) from bck_tttiex301000

truncate table tttiex300000
insert into tttiex300000 select * from SED_PSCOM.baandb.dbo.tttiex300000

truncate table tttiex301000
insert into tttiex301000 select * from SED_PSCOM.baandb.dbo.tttiex301000