set nocount on
select 'sp_dboption "'+ name +' ", ' + ' "read only", ' + ' "True" ' + char(13) + 'go' from sysdatabases where not in (select BANCO from t4bdb01..t4b_procadm_param)
set nocount off