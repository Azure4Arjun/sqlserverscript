insert into t4bdb01..t4b_monitora_acesso_banco
select	convert(char(19),getdate(),120) as data_atual
,	convert(char(12),login_time) as login_time
,	dat.name
,	loginame
,	program_name
,	cmd
from master..sysprocesses pro, master..sysdatabases dat
where	pro.dbid	=	dat.dbid
and	dat.name	not in	('master', 'msdb', 'tempdb', 'model', 'pubs', 'northwind', 't4bdb01')
group by convert(char(12),login_time)
,	dat.name
,	loginame
,	program_name
,	cmd