/*	Script para verificar jobs
	Sistema	:	SQL7.0
	Autor:		Marcelo Takeda
	Data:		14/09/2005
*/
set nocount on
declare	@data int, @nivel int, @resultado int, @ativo int, @busca varchar(50), @busca2 binary(50)
--#########################################################################--
--Colocar parametros de procura
select	@resultado	=	null		-- null = tudo / 1 = OK / 0 = ERRO
select	@ativo		=	null		-- null = tudo / 1 = ativo / 0 = desativado
select	@data		=	null		-- AAAAMMDD / NULL >= data atual
select	@busca		=	null		-- palavra a procurar
select	@busca2		=	null		-- ID a procurar
select	@nivel		=	1		-- 1 = jobs
						-- 2 = historico
						-- 3 = comandos
--#########################################################################--

if @data is null
begin
	set @data = convert(char(18),getdate(),112)
end

-- Busca por palavra
if @busca is not null
begin
	set @nivel = 4
	set @busca = '%'+upper(@busca)+'%'
select @busca
end

-- Busca por ID
if @busca2 is not null
begin
	set @nivel = 5
end

-- Jobs
if @nivel = 1
begin

select	case sysjs.last_run_outcome
		when	1	then	'OK'
		when	0	then	'ERRO'
		end as outcome
,	case sysjb.enabled
		when	1	then	'ATIVO'
		when	0	then	'DESATIVADO'
		end as enable
,	substring(sysjb.name,1,70) as job_name
,	substring(convert(varchar(10),sysjs.last_run_date),7,2) + '/' +
	substring(convert(varchar(10),sysjs.last_run_date),5,2) + '/' +
	substring(convert(varchar(10),sysjs.last_run_date),1,4) as last_run_date
,	reverse(substring(convert(varchar(10),reverse(sysjs.last_run_time)),5,2)) + ':' +
	reverse(substring(convert(varchar(10),reverse(sysjs.last_run_time)),3,2)) + ':' +
	reverse(substring(convert(varchar(10),reverse(sysjs.last_run_time)),1,2)) as last_run_time
,	reverse(substring(convert(varchar(10),reverse(sysjs.last_run_duration)),5,2)) + ':' +
	reverse(substring(convert(varchar(10),reverse(sysjs.last_run_duration)),3,2)) + ':' +
	reverse(substring(convert(varchar(10),reverse(sysjs.last_run_duration)),1,2)) as last_run_duration
,	substring(sysjs.step_name,1,50) as step_name
,	sysjb.start_step_id as start_step
,	syslg.name
,	sysjb.date_created
,	sysjb.date_modified
from		msdb.dbo.sysjobs sysjb
inner join	master.dbo.syslogins syslg
on		syslg.sid			=	sysjb.owner_sid
inner join	msdb.dbo.sysjobsteps sysjs
on		sysjs.job_id			=	sysjb.job_id
and		sysjs.step_id			=	1
where		sysjb.enabled			=	isnull(@ativo,sysjb.enabled)
and		sysjs.last_run_outcome		=	isnull(@resultado,sysjs.last_run_outcome)
order by sysjb.enabled, sysjb.name

end

-- History
if @nivel = 2
begin
select	case sysjh.run_status
		when	1	then	'OK'
		when	0	then	'ERRO'
		when	4	then	'Rodando'
		end as status
,	substring(sysjb.name,1,70) as job_name
,	sysjh.step_id
,	substring(sysjh.step_name,1,50) as step_name
,	substring(convert(varchar(10),sysjh.run_date),7,2) + '/' +
	substring(convert(varchar(10),sysjh.run_date),5,2) + '/' +
	substring(convert(varchar(10),sysjh.run_date),1,4) as run_date
,	reverse(substring(convert(varchar(10),reverse(sysjh.run_time)),5,2)) + ':' +
	reverse(substring(convert(varchar(10),reverse(sysjh.run_time)),3,2)) + ':' +
	reverse(substring(convert(varchar(10),reverse(sysjh.run_time)),1,2)) as run_time
,	reverse(substring(convert(varchar(10),reverse(sysjh.run_duration)),5,2)) + ':' +
	reverse(substring(convert(varchar(10),reverse(sysjh.run_duration)),3,2)) + ':' +
	reverse(substring(convert(varchar(10),reverse(sysjh.run_duration)),1,2)) as run_duration
,	sysjb.start_step_id as start_step
,	case sysch.freq_type
		when	1	then	'OCASIONAL'
		when	4	then	'DIARIO'
		when	8	then	'SEMANAL'
		when	16	then	'MENSAL'
		when	32	then	'MENSAL RELATIVE'
		when	64	then	'QUANDO SQLAGENT INICALIZA'
	end as freq_type
,	substring(convert(varchar(10),sysch.next_run_date),7,2) + '/' +
	substring(convert(varchar(10),sysch.next_run_date),5,2) + '/' +
	substring(convert(varchar(10),sysch.next_run_date),1,4) as next_run_date
,	reverse(substring(convert(varchar(10),reverse(sysch.next_run_time)),5,2)) + ':' +
	reverse(substring(convert(varchar(10),reverse(sysch.next_run_time)),3,2)) + ':' +
	reverse(substring(convert(varchar(10),reverse(sysch.next_run_time)),1,2)) as next_run_time
,	syslg.name
,	sysjb.date_created
,	sysjb.date_modified
from		msdb.dbo.sysjobs sysjb
inner join	master.dbo.syslogins syslg
on		syslg.sid			=	sysjb.owner_sid
inner join	msdb.dbo.sysjobhistory sysjh
on 		sysjh.job_id			=	sysjb.job_id
inner join	msdb.dbo.sysjobschedules sysch
on 		sysch.job_id			=	sysjb.job_id
where		sysjb.enabled			=	isnull(@ativo,sysjb.enabled)
and		sysjh.run_date			>=	isnull(@data,sysjh.run_date)
and		(sysjh.run_status		=	isnull(@resultado,sysjh.run_status)
or		sysjh.run_status		=	4)
order by job_name , sysjh.instance_id

end


-- Mostra os steps e os comandos
if @nivel = 3
begin

select	case sysjs.last_run_outcome
		when	1	then	'OK'
		when	0	then	'ERRO'
		end as outcome
,	substring(sysjb.name,1,70) as job_name
,	sysjs.step_id
,	sysjs.step_name
,	case sysjs.last_run_outcome
		when	1	then	'OK'
		when	0	then	'ERRO'
		end as last_run_outcome
,	sysjs.subsystem
,	sysjs.command
,	sysjs.database_name
,	reverse(substring(convert(varchar(10),reverse(sysjs.last_run_duration)),5,2)) + ':' +
	reverse(substring(convert(varchar(10),reverse(sysjs.last_run_duration)),3,2)) + ':' +
	reverse(substring(convert(varchar(10),reverse(sysjs.last_run_duration)),1,2)) as last_run_duration
,	sysjs.last_run_retries
,	substring(convert(varchar(10),sysjs.last_run_date),7,2) + '/' +
	substring(convert(varchar(10),sysjs.last_run_date),5,2) + '/' +
	substring(convert(varchar(10),sysjs.last_run_date),1,4) as last_run_date
,	reverse(substring(convert(varchar(10),reverse(sysjs.last_run_time)),5,2)) + ':' +
	reverse(substring(convert(varchar(10),reverse(sysjs.last_run_time)),3,2)) + ':' +
	reverse(substring(convert(varchar(10),reverse(sysjs.last_run_time)),1,2)) as last_run_time
,	syslg.name
,	sysjb.date_created
,	sysjb.date_modified
from		msdb.dbo.sysjobs sysjb
inner join	master.dbo.syslogins syslg
on		syslg.sid			=	sysjb.owner_sid
inner join	msdb.dbo.sysjobsteps sysjs
on		sysjs.job_id			=	sysjb.job_id
where		sysjb.enabled			=	isnull(@ativo,sysjb.enabled)
and		sysjs.last_run_outcome		=	isnull(@resultado,sysjs.last_run_outcome)
order by job_name, sysjs.step_id

end


-- Busca por palavra
if @nivel = 4
begin
select	distinct substring(sysjb.name,1,70) as job_name
,	sysjb.start_step_id as start_step
,	case sysch.freq_type
		when	1	then	'OCASIONAL'
		when	4	then	'DIARIO'
		when	8	then	'SEMANAL'
		when	16	then	'MENSAL'
		when	32	then	'MENSAL RELATIVE'
		when	64	then	'QUANDO SQLAGENT INICALIZA'
	end as freq_type
,	substring(convert(varchar(10),sysch.next_run_date),7,2) + '/' +
	substring(convert(varchar(10),sysch.next_run_date),5,2) + '/' +
	substring(convert(varchar(10),sysch.next_run_date),1,4) as next_run_date
,	reverse(substring(convert(varchar(10),reverse(sysch.next_run_time)),5,2)) + ':' +
	reverse(substring(convert(varchar(10),reverse(sysch.next_run_time)),3,2)) + ':' +
	reverse(substring(convert(varchar(10),reverse(sysch.next_run_time)),1,2)) as next_run_time
,	syslg.name
,	sysjs.command
,	sysjb.date_created
,	sysjb.date_modified
from		msdb.dbo.sysjobs sysjb
inner join	master.dbo.syslogins syslg
on		syslg.sid			=	sysjb.owner_sid
inner join	msdb.dbo.sysjobschedules sysch
on 		sysch.job_id			=	sysjb.job_id
inner join	msdb.dbo.sysjobsteps sysjs
on		sysjs.job_id			=	sysjb.job_id
where		(upper(sysjb.name)		like	@busca
or		upper(sysjs.step_name)		like	@busca
or		upper(sysjs.command)		like	@busca)
order by job_name

end


-- Busca por ID
if @nivel = 5
begin
select	substring(sysjb.name,1,70) as job_name
,	case sysch.freq_type
		when	1	then	'OCASIONAL'
		when	4	then	'DIARIO'
		when	8	then	'SEMANAL'
		when	16	then	'MENSAL'
		when	32	then	'MENSAL RELATIVE'
		when	64	then	'QUANDO SQLAGENT INICALIZA'
	end as freq_type
,	substring(convert(varchar(10),sysch.next_run_date),7,2) + '/' +
	substring(convert(varchar(10),sysch.next_run_date),5,2) + '/' +
	substring(convert(varchar(10),sysch.next_run_date),1,4) as next_run_date
,	reverse(substring(convert(varchar(10),reverse(sysch.next_run_time)),5,2)) + ':' +
	reverse(substring(convert(varchar(10),reverse(sysch.next_run_time)),3,2)) + ':' +
	reverse(substring(convert(varchar(10),reverse(sysch.next_run_time)),1,2)) as next_run_time
,	syslg.name
,	sysjb.date_created
,	sysjb.date_modified
from		msdb.dbo.sysjobs sysjb
inner join	master.dbo.syslogins syslg
on		syslg.sid			=	sysjb.owner_sid
inner join	msdb.dbo.sysjobschedules sysch
on 		sysch.job_id			=	sysjb.job_id
where		sysjb.job_id			=	@busca2
order by job_name

end



set nocount off


