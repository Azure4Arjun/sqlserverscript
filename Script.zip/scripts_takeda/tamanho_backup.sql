/*	Script para verificar hist�rico de tamanho do backup
	Sistema	:	SQL7.0 / 2000
	Autor:		Marcelo Takeda
	Data:		07/05/2008
*/
use msdb
declare	@banco varchar(30), @data varchar(23), @tipo varchar(1)
--Colocar parametros de procura ############################################--
set @data	=	null		-- >= '2008-05-07 00:00:00.000' (aaaa/mm/dd)
set @banco	=	null		-- ID do job a ser procurado
set @tipo	=	'D'		-- D = Dados		/ Baan = id
--#########################################################################--
set nocount on
select @data = DATEADD(day,-1,getdate())


if (select @banco) is not null
begin
	select	backup_set_id
	,	type
	,	backup_finish_date
	,	convert(numeric(10,2),((backup_size/1024)/1024)) backup_size_MB
	,	substring(database_name,1,30) as 'database'
	,	substring(server_name,1,30) as 'server'
	,	substring(user_name, 1,30) as 'user'
	,	software_major_version
	,	database_creation_date
	,	backup_start_date
	,	sort_order
	,	code_page
	,	compatibility_level
	,	machine_name
	from backupset
	where	database_name		=	@banco
	and	type			=	isnull(@tipo,type)
	order by backup_finish_date desc
end

select	backup_set_id
,	type
,	backup_finish_date
,	convert(numeric(10,2),((backup_size/1024)/1024)) backup_size_MB
,	substring(database_name,1,30) as 'database'
,	substring(server_name,1,30) as 'server'
,	substring(user_name, 1,30) as 'user'
,	software_major_version
,	database_creation_date
,	backup_start_date
,	sort_order
,	code_page
,	compatibility_level
,	machine_name
from backupset
where	type			=	isnull(@tipo,type)
and	backup_finish_date	>=	isnull(@data,type)
order by backup_finish_date desc, database_name






