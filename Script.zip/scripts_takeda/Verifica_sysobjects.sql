/*	Script para verificar a sysobjects devido a objetos inexistentes
	Versao do SQL	: 7.0 / 2000
	Criado por	: Marcelo Takeda
	Data		: 15/01/2007
*/

sp_MSforeachdb	@command1 = "select '?'"
,		@command2 = "select id, uid,name from ?..sysobjects where name = 'XXX'"

-- delete from sysobjects where name = 'XXX'

select * from sysobjects where name = 'XXX'

select * from sysusers where uid = 0

select count(*) from XXX

dbcc checkdb

-- sp_configure 'allow updates', '1'
-- RECONFIGURE WITH OVERRIDE
