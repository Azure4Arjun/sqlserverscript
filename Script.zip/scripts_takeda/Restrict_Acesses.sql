USE master
go

EXEC sp_dboption 'OPVD', 'read only', 'TRUE'
go

EXEC sp_dboption 'OPTEMP', 'read only', 'TRUE'
go

EXEC sp_dboption 'OPVD_WK', 'read only', 'TRUE'
go

