/* Script para a cria��o de um Link entre servidores
   Tanto 7.0 quanto 6.5
   (Para usar o link entre os servidores o usu�rio deve ser o mesmo e ter a mesma senha)

   Criado por	: Marcelo Takeda
   Data		: 18/09/2001
*/

-- Sequ�ncia para verifica��o do link
/*
sp_helpserver USE MASTER
select * from 
sp_helpremotelogin
select @@servername
*/

-- Link dos servidores
--	sp_dropserver 'VAREJO'
--	sp_dropserver 'VAREJO', 'droplogins'
--	go
EXEC sp_addlinkedserver 'VAREJO'
go

-- SP para a liga��o de 6.5
--	sp_addserver VAREJO

-- SP para adicionar o @@servername
--	sp_addserver 'SED-XXXXXX', 'LOCAL'

-- Op��es do link
EXEC sp_serveroption 'VAREJO', 'rpc', 'TRUE'
go

-- Ajuste do nome do servidor
EXEC sp_setnetname 'VAREJO','172.17.2.10'
go

-- Op��es de login
EXEC sp_addremotelogin 'VAREJO' --,sa,sa
go
EXEC sp_remoteoption 'VAREJO',null,null, 'trusted', 'TRUE'
go

-- Teste do link
--	exec VAREJO.master..sp_who

