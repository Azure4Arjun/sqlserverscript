select 'sp_defaultdb "' + name + '", "PRD_MIS"' + char(13) + 'go' + char(13)

from syslogins

order by language

go

 
