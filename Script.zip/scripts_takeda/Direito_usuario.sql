/*
	Script que verifica os usuarios e os direitos.
*/
--	Parametros Iniciais
set nocount on
use master
go
declare @nomebd		varchar(30)
,	@comando	varchar(550)
,	@usuario	varchar(30)
,	@role		varchar(30)

--	Tabelas tempor�rias
select name into #tmp_bd
from sysdatabases
where	upper(name)	=	upper(isnull(@nomebd,name))
order by name

create table #tmp_usuario
(	server	varchar(30)
,	banco 	varchar(30)
,	role	varchar(30)
,	usuario	varchar(30))

create table #tmp_srv
(	server_srv	varchar(15)
,	role_srv	varchar(30)
,	usuario_srv	varchar(30))



--	Principal
	insert #tmp_srv
	select @@servername, substring(spv.name,1,30), substring(lgn.name,1,30)
	from	master.dbo.spt_values spv, master.dbo.sysxlogins lgn
	where	spv.low = 0
	and	spv.type = 'SRV'
	and	lgn.srvid IS NULL
	and	spv.number & lgn.xstatus = spv.number
	and	upper(lgn.name) = upper(isnull(@usuario,lgn.name))
	while (select count(*) from #tmp_bd) <> 0
	begin
		select top 1 @nomebd = substring(name,1,30) from #tmp_bd
		select @comando = 'insert #tmp_usuario select "'+ @@servername +'", "['+ @nomebd +']", substring(g.name,1,30), substring(u.name,1,30)
		from ['+ @nomebd +']..sysusers u, ['+ @nomebd +']..sysusers g, ['+ @nomebd +']..sysmembers m
		where	g.uid = m.groupuid
		and	u.uid = m.memberuid
		and	g.issqlrole = 1
		and	u.status <> 0
		order by g.name'
		exec (@comando)
		delete from #tmp_bd where upper(@nomebd) = upper(name)
	end

	select *
	from		#tmp_srv
	order by role_srv

	select distinct * from #tmp_usuario
	order by banco, role


--	Parametros Finais
drop table #tmp_usuario
go
drop table #tmp_srv
go
drop table #tmp_bd
go

set nocount off

