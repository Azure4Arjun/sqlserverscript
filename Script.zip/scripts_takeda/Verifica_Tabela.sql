/* 	Script para verificar as tabelas que possuem determinado campo
	E verificar os objetos dependentes de uma tabela
	Criado por:	Marcelo Takeda
	Vers�o:		SQL7.0
	Data:		18/10/2005
*/
-- Variaveis
declare @nome_objeto 	varchar(50),	@nome_objeto2 	varchar(50),	@tipo		varchar(2)
--&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

set	@nome_objeto	=	''		-- Objeto / campo

-- sp_helptext  &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
select @tipo = xtype from sysobjects where name = @nome_objeto
select @nome_objeto2 = '%' + @nome_objeto + '%'

--	Verifica coluna em tabelas
if (select @tipo) is null
begin
	select	substring(sysob.name,1,50) as tabela, sysob.xtype, substring(sysco.name,1,20) as coluna
	from		sysobjects sysob
	inner join	syscolumns sysco
	on		sysob.id		=	sysco.id
	where		sysco.name		=	@nome_objeto
	order by	tabela, coluna
end

--	Verfica se h� objetos relacionados
else
begin
select	distinct	@nome_objeto  as 'Objeto Original'
,			substring(sysob.name,1,50) as 'Objeto Relacionado'
,			sysco.id as 'id'
from		syscomments sysco
inner join	sysobjects sysob
on		sysco.id		=	sysob.id
where		text			like	@nome_objeto2
end

