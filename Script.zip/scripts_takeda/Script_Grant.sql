/*
======================================================================================================================================================
Comando cria script que da Grant ao determinado usu�rio
======================================================================================================================================================
*/

-- Cria script de Grant
USE [BANCO]
GO
SELECT 'GRANT EXECUTE ON [' + NAME + '] TO ' + '[usu�rio]'+ CHAR(10)+'GO' FROM SYSOBJECTS
WHERE NAME in 
('XXXXXXXXXXX', 'XXXXXXXXXXX')

-- Exemplo
USE CADUNIC
GO
SELECT 'GRANT SELECT ON [' + NAME + '] TO ' + 'usr_sgrc'+ CHAR(10)+'GO' FROM SYSOBJECTS
where name in ('TB_ATIVIDADE', 'TB_SETOR ', 'TB_CNAE ', 'TbEndereco', 'TbPessoa', 'TbPessoaJuridica')
